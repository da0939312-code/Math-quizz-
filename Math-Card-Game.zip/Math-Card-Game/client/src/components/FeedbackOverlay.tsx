import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, XCircle, ArrowRight } from "lucide-react";

interface FeedbackOverlayProps {
  isVisible: boolean;
  isCorrect: boolean;
  explanation: string;
  onNext: () => void;
}

export function FeedbackOverlay({ isVisible, isCorrect, explanation, onNext }: FeedbackOverlayProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
        >
          <motion.div
            initial={{ scale: 0.8, y: 50 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.8, y: 50 }}
            className="w-full max-w-lg bg-white shadow-2xl rounded-3xl overflow-hidden"
          >
            <div className={`p-8 text-center ${isCorrect ? 'bg-green-50' : 'bg-red-50'}`}>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 15 }}
                className="flex justify-center mb-4"
              >
                {isCorrect ? (
                  <CheckCircle2 className="w-20 h-20 text-green-500" />
                ) : (
                  <XCircle className="w-20 h-20 text-red-500" />
                )}
              </motion.div>
              
              <h2 className={`text-4xl font-black mb-2 font-display uppercase tracking-wider ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
                {isCorrect ? "BENAR!" : "SALAH!"}
              </h2>
              
              <p className="text-lg text-gray-600 font-medium leading-relaxed">
                {explanation}
              </p>
            </div>
            
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex justify-center">
               <button
                  onClick={onNext}
                  className="flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-white shadow-lg
                             bg-gradient-to-r from-primary to-purple-600 
                             hover:shadow-xl hover:scale-105 active:scale-95 transition-all"
               >
                  Lanjut <ArrowRight className="w-5 h-5" />
               </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
