import { useState } from "react";
import { useLocation, Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Play, BookOpen, Calculator, Sigma, Pi, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { STUDY_MATERIALS } from "@/lib/questions";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function Home() {
  const [_, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 overflow-hidden relative bg-gradient-to-b from-blue-50 to-purple-50">
      
      {/* Background Decorations */}
      <motion.div 
        animate={{ rotate: 360 }}
        transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
        className="absolute top-20 left-10 text-primary/10"
      >
        <Calculator size={120} />
      </motion.div>
      <motion.div 
        animate={{ rotate: -360 }}
        transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
        className="absolute bottom-20 right-10 text-accent/20"
      >
        <Sigma size={150} />
      </motion.div>
      <motion.div 
        animate={{ y: [0, -20, 0] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-1/2 right-20 text-success/10"
      >
        <Pi size={100} />
      </motion.div>

      <div className="relative z-10 text-center max-w-2xl w-full">
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, type: "spring" }}
        >
          <h2 className="text-xl md:text-2xl font-bold text-accent tracking-widest uppercase mb-4 font-display">
            Matematika Kelas X
          </h2>
          <h1 className="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-primary via-purple-500 to-pink-500 font-display mb-6 drop-shadow-sm">
            LET'S PLAY
          </h1>
          <p className="text-lg text-gray-500 mb-12 max-w-md mx-auto">
            Tantang dirimu dengan soal matematika seru! Eksponen, Aljabar, dan Trigonometri menanti.
          </p>
        </motion.div>

        <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
          <Dialog>
            <DialogTrigger asChild>
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5, type: "spring" }}
                className="group relative inline-flex items-center justify-center cursor-pointer"
              >
                <div className="absolute inset-0 bg-primary rounded-2xl blur-xl opacity-40 group-hover:opacity-60 transition-opacity duration-500"></div>
                <button className="relative px-12 py-6 bg-white rounded-2xl font-black text-2xl md:text-3xl text-primary shadow-xl border-b-8 border-primary/20 hover:border-primary hover:-translate-y-2 active:translate-y-0 active:border-b-0 transition-all duration-200 flex items-center gap-4">
                  <Play className="fill-current w-8 h-8" />
                  START
                </button>
              </motion.div>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] rounded-3xl border-none shadow-2xl">
              <DialogHeader>
                <DialogTitle className="text-2xl font-black text-center text-gray-800">Pilih Level</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 gap-4 py-4">
                <Button 
                  onClick={() => setLocation("/game?level=mudah")}
                  className="bg-green-500 hover:bg-green-600 text-white font-black text-xl py-8 rounded-2xl shadow-lg border-b-4 border-green-700 active:border-b-0 active:translate-y-1 transition-all"
                >
                  MUDAH
                </Button>
                <Button 
                  onClick={() => setLocation("/game?level=medium")}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white font-black text-xl py-8 rounded-2xl shadow-lg border-b-4 border-yellow-700 active:border-b-0 active:translate-y-1 transition-all"
                >
                  MEDIUM
                </Button>
                <Button 
                  onClick={() => setLocation("/game?level=susah")}
                  className="bg-red-500 hover:bg-red-600 text-white font-black text-xl py-8 rounded-2xl shadow-lg border-b-4 border-red-700 active:border-b-0 active:translate-y-1 transition-all"
                >
                  SUSAH
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6, type: "spring" }}
                className="group relative inline-flex items-center justify-center cursor-pointer"
              >
                <button className="px-12 py-6 bg-white/80 backdrop-blur-sm rounded-2xl font-black text-2xl md:text-3xl text-gray-600 shadow-lg border-b-8 border-gray-200 hover:border-gray-300 hover:-translate-y-2 active:translate-y-0 active:border-b-0 transition-all duration-200 flex items-center gap-4">
                  <BookOpen className="w-8 h-8" />
                  MATERI
                </button>
              </motion.div>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto rounded-3xl border-none shadow-2xl p-6 md:p-10">
              <DialogHeader className="mb-8">
                <DialogTitle className="text-4xl font-black text-center bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-600">
                  Materi Pembelajaran
                </DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {STUDY_MATERIALS.map((material, idx) => (
                  <Card key={idx} className="border-none bg-blue-50/50 rounded-3xl overflow-hidden hover:shadow-xl transition-shadow duration-300">
                    <CardHeader className="bg-white/60 backdrop-blur-sm border-b border-blue-100">
                      <CardTitle className="text-primary text-2xl font-black flex items-center gap-2">
                        <ChevronRight className="w-6 h-6" />
                        {material.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6 space-y-6">
                      <p className="text-gray-600 font-bold leading-relaxed">{material.content}</p>
                      <div className="bg-white p-6 rounded-2xl shadow-inner border border-blue-100">
                        <p className="text-xs font-black text-blue-400 mb-4 uppercase tracking-widest flex items-center gap-2">
                          <Sigma className="w-4 h-4" />
                          Rumus Penting
                        </p>
                        <div className="flex flex-col gap-3">
                          {material.formulas.map((formula, fIdx) => (
                            <div key={fIdx} className="bg-blue-50 px-4 py-3 rounded-xl border-l-4 border-primary text-primary font-mono font-black text-lg">
                              {formula}
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <footer className="absolute bottom-6 text-center text-gray-400 text-sm font-medium">
        Kurikulum Merdeka • SMA Kelas X
      </footer>
    </div>
  );
}
