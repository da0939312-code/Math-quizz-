## Packages
framer-motion | Complex animations for game cards and feedback overlays
canvas-confetti | Celebration effects for high scores
@types/canvas-confetti | Types for confetti
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ['"Fredoka"', 'cursive'],
  body: ['"Nunito"', 'sans-serif'],
}
