import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameResultSchema } from "@shared/schema";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post(api.results.create.path, async (req, res) => {
    try {
      const data = insertGameResultSchema.parse(req.body);
      const result = await storage.createGameResult(data);
      res.status(201).json(result);
    } catch (e) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.get(api.results.list.path, async (req, res) => {
    const results = await storage.getTopResults();
    res.json(results);
  });

  return httpServer;
}
