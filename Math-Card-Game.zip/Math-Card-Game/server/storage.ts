import { gameResults, type GameResult, type InsertGameResult } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createGameResult(result: InsertGameResult): Promise<GameResult>;
  getTopResults(): Promise<GameResult[]>;
}

export class DatabaseStorage implements IStorage {
  async createGameResult(result: InsertGameResult): Promise<GameResult> {
    const [row] = await db.insert(gameResults).values(result).returning();
    return row;
  }
  async getTopResults(): Promise<GameResult[]> {
    // Return top 10 scores
    // Note: score is stored as text in schema for simplicity, but for sorting we might want numbers
    // For this simple app, we'll just return recent ones or trust the text sort if format is padded
    return await db.select().from(gameResults).orderBy(desc(gameResults.id)).limit(10);
  }
}

export const storage = new DatabaseStorage();
