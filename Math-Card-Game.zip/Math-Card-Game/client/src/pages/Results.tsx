import { useEffect } from "react";
import { useLocation } from "wouter";
import confetti from "canvas-confetti";
import { motion } from "framer-motion";
import { RefreshCcw, Home, Trophy, Star } from "lucide-react";
import { QUESTIONS } from "@/lib/questions";
import { useSubmitResult } from "@/hooks/use-results";

export default function Results() {
  const [location, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const score = parseInt(searchParams.get("score") || "0", 10);
  const totalScore = QUESTIONS.length * 10;
  
  const percentage = Math.round((score / totalScore) * 100);
  const { mutate: saveResult } = useSubmitResult();

  useEffect(() => {
    if (percentage > 50) {
      const duration = 3 * 1000;
      const animationEnd = Date.now() + duration;
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

      const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

      const interval: any = setInterval(function() {
        const timeLeft = animationEnd - Date.now();

        if (timeLeft <= 0) {
          return clearInterval(interval);
        }

        const particleCount = 50 * (timeLeft / duration);
        confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
        confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
      }, 250);
    }

    // Save result (fire and forget)
    saveResult({
      playerName: "Guest Player",
      score: score.toString(),
      completedAt: new Date().toISOString()
    });

  }, [percentage, score, saveResult]);

  let message = "Semangat! Coba Lagi!";
  let icon = <Star className="w-16 h-16 text-gray-400" />;
  
  if (percentage >= 80) {
    message = "Luar Biasa! Kamu Jenius!";
    icon = <Trophy className="w-16 h-16 text-yellow-500 fill-current" />;
  } else if (percentage >= 60) {
    message = "Kerja Bagus!";
    icon = <Star className="w-16 h-16 text-primary fill-current" />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-indigo-50 to-blue-100">
      <motion.div 
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
        className="bg-white rounded-[2.5rem] p-8 md:p-12 shadow-2xl max-w-lg w-full text-center border-4 border-white ring-4 ring-primary/10"
      >
        <div className="flex justify-center mb-6">
          <div className="p-6 bg-gray-50 rounded-full shadow-inner">
            {icon}
          </div>
        </div>

        <h1 className="text-4xl md:text-5xl font-black font-display text-gray-800 mb-2">
          {score}
          <span className="text-xl text-gray-400 font-bold ml-2">/ {totalScore}</span>
        </h1>
        
        <h2 className="text-2xl font-bold text-primary mb-8 font-display">{message}</h2>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-blue-50 p-4 rounded-2xl">
            <div className="text-2xl font-black text-blue-600">{QUESTIONS.length}</div>
            <div className="text-xs font-bold text-blue-400 uppercase">Total Soal</div>
          </div>
          <div className="bg-green-50 p-4 rounded-2xl">
            <div className="text-2xl font-black text-green-600">{score / 10}</div>
            <div className="text-xs font-bold text-green-400 uppercase">Benar</div>
          </div>
        </div>

        <div className="space-y-3">
          <button 
            onClick={() => setLocation("/game")}
            className="w-full py-4 rounded-xl bg-primary text-white font-bold text-lg shadow-lg hover:bg-primary/90 hover:shadow-xl hover:-translate-y-1 transition-all flex items-center justify-center gap-2"
          >
            <RefreshCcw className="w-5 h-5" /> Main Lagi
          </button>
          
          <button 
            onClick={() => setLocation("/")}
            className="w-full py-4 rounded-xl bg-white text-gray-600 font-bold text-lg border-2 border-gray-100 hover:border-gray-200 hover:bg-gray-50 transition-all flex items-center justify-center gap-2"
          >
            <Home className="w-5 h-5" /> Kembali ke Menu
          </button>
        </div>
      </motion.div>
    </div>
  );
}
