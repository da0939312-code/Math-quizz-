import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface GameCardProps {
  option: string;
  index: number;
  isSelected?: boolean;
  isCorrect?: boolean;
  isWrong?: boolean;
  disabled?: boolean;
  onClick: () => void;
}

export function GameCard({ 
  option, 
  index, 
  isSelected, 
  isCorrect, 
  isWrong, 
  disabled, 
  onClick 
}: GameCardProps) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, type: "spring", stiffness: 300, damping: 20 }}
      whileHover={!disabled ? { scale: 1.02, translateY: -5 } : {}}
      whileTap={!disabled ? { scale: 0.95 } : {}}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "relative w-full p-8 rounded-3xl text-2xl font-bold text-center transition-colors duration-300 shadow-lg border-b-8",
        // Default state
        "bg-white text-gray-700 border-gray-200 hover:border-primary/50",
        // Hover state (handled by JS for scaling, but color here)
        !disabled && "hover:text-primary",
        // Correct State
        isCorrect && "bg-green-100 text-green-700 border-green-500 ring-4 ring-green-300",
        // Wrong State
        isWrong && "bg-red-100 text-red-700 border-red-500 ring-4 ring-red-300",
        // Disabled but not selected
        disabled && !isCorrect && !isWrong && "opacity-50 cursor-not-allowed"
      )}
    >
      <span className="absolute top-4 left-4 text-sm font-black text-gray-300 opacity-50 font-display">
        {String.fromCharCode(65 + index)}
      </span>
      {option}
    </motion.button>
  );
}
