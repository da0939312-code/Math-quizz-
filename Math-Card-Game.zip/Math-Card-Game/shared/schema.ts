import { pgTable, text, serial, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// We won't strictly use a DB for the game logic as requested (client-side array),
// but we define the shape here for type safety across the app.
export const gameResults = pgTable("game_results", {
  id: serial("id").primaryKey(),
  playerName: text("player_name").notNull(),
  score: text("score").notNull(), // Storing as text to be safe/simple
  completedAt: text("completed_at").notNull(),
});

export const insertGameResultSchema = createInsertSchema(gameResults).omit({ id: true });

export type GameResult = typeof gameResults.$inferSelect;
export type InsertGameResult = z.infer<typeof insertGameResultSchema>;

// Game Question Type Definition (Client-side usage mainly)
export interface Question {
  id: number;
  question: string;
  options: string[];
  answer: string; // The correct string from options
  explanation: string;
  topic: string;
  level: "mudah" | "medium" | "susah";
}
