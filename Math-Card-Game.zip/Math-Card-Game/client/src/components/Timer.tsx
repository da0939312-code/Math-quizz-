import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface TimerProps {
  duration: number;
  onTimeUp: () => void;
  isRunning: boolean;
}

export function Timer({ duration, onTimeUp, isRunning }: TimerProps) {
  const [timeLeft, setTimeLeft] = useState(duration);

  useEffect(() => {
    setTimeLeft(duration);
  }, [duration]);

  useEffect(() => {
    if (!isRunning) return;
    
    if (timeLeft <= 0) {
      onTimeUp();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isRunning, onTimeUp]);

  const percentage = (timeLeft / duration) * 100;
  
  // Color logic
  let colorClass = "bg-primary";
  if (percentage < 60) colorClass = "bg-yellow-400";
  if (percentage < 30) colorClass = "bg-red-500";

  return (
    <div className="w-full max-w-xs mx-auto mb-8">
      <div className="flex justify-between items-end mb-2 px-1">
        <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Waktu</span>
        <span className={`text-xl font-black font-mono ${percentage < 30 ? 'text-red-500 animate-pulse' : 'text-gray-700'}`}>
          00:{timeLeft.toString().padStart(2, '0')}
        </span>
      </div>
      <div className="h-4 bg-gray-200 rounded-full overflow-hidden shadow-inner border border-gray-100">
        <motion.div 
          className={`h-full ${colorClass} rounded-full`}
          initial={{ width: "100%" }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, ease: "linear" }}
        />
      </div>
    </div>
  );
}
