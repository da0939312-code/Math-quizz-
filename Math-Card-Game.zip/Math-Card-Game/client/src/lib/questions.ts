import type { Question } from "@shared/schema";

export const QUESTIONS: Question[] = [
  // --- LEVEL: MUDAH ---
  {
    id: 1,
    topic: "Eksponen",
    question: "Bentuk sederhana dari (2³)² adalah...",
    options: ["2⁵", "2⁶", "2⁹", "2¹"],
    answer: "2⁶",
    explanation: "Sifat eksponen (aᵐ)ⁿ = aᵐⁿ. Jadi (2³)² = 2⁽³ˣ²⁾ = 2⁶.",
    level: "mudah"
  },
  {
    id: 2,
    topic: "Persamaan Linear",
    question: "Nilai x yang memenuhi persamaan 2x + 5 = 15 adalah...",
    options: ["5", "10", "2", "7"],
    answer: "5",
    explanation: "2x + 5 = 15 → 2x = 10 → x = 5.",
    level: "mudah"
  },
  {
    id: 3,
    topic: "Trigonometri",
    question: "Nilai dari sin 30° adalah...",
    options: ["1/2", "1/3", "√3/2", "1"],
    answer: "1/2",
    explanation: "Sin 30° adalah nilai istimewa trigonometri yang bernilai 1/2.",
    level: "mudah"
  },
  {
    id: 4,
    topic: "Statistika",
    question: "Rata-rata dari data: 4, 6, 8, 10 adalah...",
    options: ["6", "7", "8", "9"],
    answer: "7",
    explanation: "(4+6+8+10)/4 = 28/4 = 7.",
    level: "mudah"
  },
  {
    id: 5,
    topic: "Peluang",
    question: "Peluang muncul angka pada pelemparan sebuah koin adalah...",
    options: ["1/4", "1/3", "1/2", "1"],
    answer: "1/2",
    explanation: "Ruang sampel {Angka, Gambar}. Peluang Angka = 1/2.",
    level: "mudah"
  },
  {
    id: 6,
    topic: "Trigonometri",
    question: "Nilai dari cos 0° adalah...",
    options: ["0", "1", "-1", "∞"],
    answer: "1",
    explanation: "Cos 0° bernilai 1.",
    level: "mudah"
  },
  {
    id: 7,
    topic: "Pertidaksamaan",
    question: "Himpunan penyelesaian dari 3x - 2 < 7 adalah...",
    options: ["x < 3", "x > 3", "x < 5", "x > 5"],
    answer: "x < 3",
    explanation: "3x < 9 → x < 3.",
    level: "mudah"
  },
  {
    id: 8,
    topic: "Sistem Persamaan Linear",
    question: "Jika x + y = 5 dan x - y = 1, maka nilai x adalah...",
    options: ["2", "3", "4", "5"],
    answer: "3",
    explanation: "Jumlahkan kedua persamaan: 2x = 6 → x = 3.",
    level: "mudah"
  },
  {
    id: 9,
    topic: "Eksponen",
    question: "Hasil dari 5² × 5³ adalah...",
    options: ["5⁵", "5⁶", "5¹", "25⁵"],
    answer: "5⁵",
    explanation: "aᵐ × aⁿ = aᵐ⁺ⁿ. Jadi 5² × 5³ = 5²⁺³ = 5⁵.",
    level: "mudah"
  },
  {
    id: 10,
    topic: "Operasi Bilangan",
    question: "Hasil dari -12 + 7 - (-5) adalah...",
    options: ["0", "10", "-10", "24"],
    answer: "0",
    explanation: "-12 + 7 + 5 = -5 + 5 = 0.",
    level: "mudah"
  },

  // --- LEVEL: MEDIUM ---
  {
    id: 11,
    topic: "Barisan Aritmatika",
    question: "Suku ke-5 dari barisan 2, 5, 8, ... adalah...",
    options: ["11", "13", "14", "15"],
    answer: "14",
    explanation: "a=2, b=3. U₅ = a + 4b = 2 + 4(3) = 2 + 12 = 14.",
    level: "medium"
  },
  {
    id: 12,
    topic: "Akar Bilangan",
    question: "Hasil dari √75 + 2√3 adalah...",
    options: ["5√3", "7√3", "9√3", "11√3"],
    answer: "7√3",
    explanation: "√75 = √(25×3) = 5√3. Jadi 5√3 + 2√3 = 7√3.",
    level: "medium"
  },
  {
    id: 13,
    topic: "Fungsi Kuadrat",
    question: "Titik potong grafik y = x² - 4 dengan sumbu X adalah...",
    options: ["(2,0) & (-2,0)", "(4,0) & (-4,0)", "(0,2) & (0,-2)", "(0,4) & (0,-4)"],
    answer: "(2,0) & (-2,0)",
    explanation: "x² - 4 = 0 → (x-2)(x+2) = 0 → x = 2 atau x = -2.",
    level: "medium"
  },
  {
    id: 14,
    topic: "Logaritma",
    question: "Nilai dari ²log 8 + ²log 4 adalah...",
    options: ["3", "4", "5", "6"],
    answer: "5",
    explanation: "²log 8 = 3, ²log 4 = 2. Jadi 3 + 2 = 5.",
    level: "medium"
  },
  {
    id: 15,
    topic: "Vektor",
    question: "Panjang vektor a = (3, 4) adalah...",
    options: ["5", "7", "12", "25"],
    answer: "5",
    explanation: "|a| = √(3² + 4²) = √(9 + 16) = √25 = 5.",
    level: "medium"
  },
  {
    id: 16,
    topic: "Barisan Geometri",
    question: "Rasio dari barisan 3, 6, 12, 24, ... adalah...",
    options: ["2", "3", "4", "1/2"],
    answer: "2",
    explanation: "r = U₂/U₁ = 6/3 = 2.",
    level: "medium"
  },
  {
    id: 17,
    topic: "Logaritma",
    question: "Jika ³log 27 = x, maka nilai x adalah...",
    options: ["2", "3", "4", "5"],
    answer: "3",
    explanation: "3³ = 27, maka ³log 27 = 3.",
    level: "medium"
  },
  {
    id: 18,
    topic: "Vektor",
    question: "Jika vektor u = (1, 2) dan v = (3, -1), maka u + v adalah...",
    options: ["(4, 1)", "(4, 3)", "(2, 3)", "(-2, 3)"],
    answer: "(4, 1)",
    explanation: "u + v = (1+3, 2-1) = (4, 1).",
    level: "medium"
  },
  {
    id: 19,
    topic: "Statistika",
    question: "Median dari data: 2, 5, 7, 8, 10 adalah...",
    options: ["5", "7", "8", "7.5"],
    answer: "7",
    explanation: "Data terurut, nilai tengahnya adalah 7.",
    level: "medium"
  },
  {
    id: 20,
    topic: "Fungsi Kuadrat",
    question: "Nilai optimum (minimum) dari y = x² - 2x + 1 adalah...",
    options: ["0", "1", "-1", "2"],
    answer: "0",
    explanation: "y = (x-1)². Nilai minimum adalah 0 saat x=1.",
    level: "medium"
  },

  // --- LEVEL: SUSAH ---
  {
    id: 21,
    topic: "Matriks",
    question: "Jika A = [1 2; 3 4], maka determinan A adalah...",
    options: ["-2", "2", "10", "-10"],
    answer: "-2",
    explanation: "Det(A) = ad - bc = (1)(4) - (2)(3) = 4 - 6 = -2.",
    level: "susah"
  },
  {
    id: 22,
    topic: "Matriks",
    question: "Invers dari matriks [1 2; 3 4] memiliki determinan...",
    options: ["-1/2", "1/2", "-2", "2"],
    answer: "-1/2",
    explanation: "Det(A⁻¹) = 1/Det(A). Det(A) = -2, maka Det(A⁻¹) = -1/2.",
    level: "susah"
  },
  {
    id: 23,
    topic: "Trigonometri",
    question: "Jika sin A = 3/5 (A lancip), maka nilai cos A adalah...",
    options: ["4/5", "3/4", "1/5", "2/5"],
    answer: "4/5",
    explanation: "cos²A = 1 - sin²A = 1 - 9/25 = 16/25. cos A = 4/5.",
    level: "susah"
  },
  {
    id: 24,
    topic: "Eksponen",
    question: "Penyelesaian dari 2ˣ⁺¹ = 8 adalah...",
    options: ["1", "2", "3", "4"],
    answer: "2",
    explanation: "2ˣ⁺¹ = 2³. x + 1 = 3 → x = 2.",
    level: "susah"
  },
  {
    id: 25,
    topic: "Logaritma",
    question: "Nilai dari ⁹log 81 + ³log 1/9 adalah...",
    options: ["0", "1", "2", "4"],
    answer: "0",
    explanation: "⁹log 81 = 2, ³log 1/9 = -2. 2 + (-2) = 0.",
    level: "susah"
  },
  {
    id: 26,
    topic: "Barisan Aritmatika",
    question: "Jumlah 10 suku pertama dari 2, 4, 6, ... adalah...",
    options: ["110", "100", "120", "90"],
    answer: "110",
    explanation: "S₁₀ = 10/2 (2(2) + 9(2)) = 5 (4 + 18) = 5(22) = 110.",
    level: "susah"
  },
  {
    id: 27,
    topic: "Vektor",
    question: "Hasil perkalian skalar (dot product) u = (2, 3) dan v = (4, -1) adalah...",
    options: ["5", "11", "8", "-3"],
    answer: "5",
    explanation: "u · v = (2)(4) + (3)(-1) = 8 - 3 = 5.",
    level: "susah"
  },
  {
    id: 28,
    topic: "Fungsi Kuadrat",
    question: "Persamaan sumbu simetri dari y = 2x² - 8x + 5 adalah...",
    options: ["x = 2", "x = -2", "x = 4", "x = 1"],
    answer: "x = 2",
    explanation: "x = -b/2a = -(-8)/(2*2) = 8/4 = 2.",
    level: "susah"
  },
  {
    id: 29,
    topic: "Peluang",
    question: "Dua buah dadu dilempar. Peluang muncul jumlah mata dadu 7 adalah...",
    options: ["1/6", "1/12", "1/36", "1/4"],
    answer: "1/6",
    explanation: "Pasangan jumlah 7: (1,6),(6,1),(2,5),(5,2),(3,4),(4,3) ada 6. Total 36. 6/36 = 1/6.",
    level: "susah"
  },
  {
    id: 30,
    topic: "Statistika",
    question: "Simpangan baku dari data: 2, 2, 2, 2 adalah...",
    options: ["0", "1", "2", "4"],
    answer: "0",
    explanation: "Karena semua data sama, tidak ada variasi (simpangan).",
    level: "susah"
  }
];

export const STUDY_MATERIALS = [
  {
    title: "Eksponen (Pangkat)",
    content: "Eksponen adalah perkalian berulang. Sifat-sifat: aᵐ × aⁿ = aᵐ⁺ⁿ, (aᵐ)ⁿ = aᵐⁿ, aᵐ / aⁿ = aᵐ⁻ⁿ.",
    formulas: ["a^m * a^n = a^{m+n}", "(a^m)^n = a^{m*n}", "a^m / a^n = a^{m-n}"]
  },
  {
    title: "Persamaan Linear",
    content: "Persamaan dengan variabel berpangkat satu. Tujuan: mencari nilai variabel agar persamaan bernilai benar.",
    formulas: ["ax + b = c"]
  },
  {
    title: "Trigonometri",
    content: "Perbandingan sisi-sisi segitiga siku-siku. Nilai istimewa: sin 30° = 1/2, cos 60° = 1/2, tan 45° = 1.",
    formulas: ["sin A = depan / miring", "cos A = samping / miring", "tan A = depan / samping"]
  },
  {
    title: "Barisan Aritmatika",
    content: "Barisan dengan selisih (beda) tetap antar suku.",
    formulas: ["U_n = a + (n-1)b", "S_n = n/2 (a + U_n)"]
  }
];
