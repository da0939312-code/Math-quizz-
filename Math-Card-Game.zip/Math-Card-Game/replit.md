# Replit.md

## Overview

This is an interactive math quiz game application for Grade 10 students (Matematika Kelas X). The app presents users with 15 randomized math questions covering topics like exponents, linear equations, trigonometry, and arithmetic sequences. Players answer timed questions, receive immediate feedback with explanations, and their scores are saved to a leaderboard.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Animations**: Framer Motion for card animations and transitions
- **Effects**: canvas-confetti for celebration effects on high scores
- **Build Tool**: Vite with custom plugins for Replit integration

The frontend follows a page-based structure with three main views:
- Home: Landing page with play button
- Game: Quiz interface with timer, question cards, and feedback overlays
- Results: Score display with confetti effects

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM with PostgreSQL
- **API Design**: Simple REST endpoints defined in shared route definitions
- **Build**: esbuild for production bundling with dependency allowlisting

The server uses a clean separation:
- `server/routes.ts`: API endpoint registration
- `server/storage.ts`: Database access layer implementing IStorage interface
- `server/db.ts`: Database connection pool

### Data Storage
- **Database**: PostgreSQL via Drizzle ORM
- **Schema**: Single `game_results` table storing player scores
- **Schema Location**: `shared/schema.ts` (shared between client and server)

Game questions are stored client-side in `client/src/lib/questions.ts` as a static array - this is intentional to keep quiz logic on the client.

### Shared Code Pattern
The `shared/` directory contains code used by both frontend and backend:
- `schema.ts`: Database schema and Zod validation schemas
- `routes.ts`: API route definitions with type-safe request/response schemas

### Build System
- Development: Vite dev server with HMR, Express backend via tsx
- Production: Vite builds client to `dist/public`, esbuild bundles server to `dist/index.cjs`
- Database migrations: `drizzle-kit push` for schema synchronization

## External Dependencies

### Database
- PostgreSQL (required, connection via `DATABASE_URL` environment variable)
- Drizzle ORM for type-safe queries
- connect-pg-simple for session storage (available but not currently used)

### UI Component Library
- shadcn/ui components (Radix UI primitives with Tailwind styling)
- Full component set installed in `client/src/components/ui/`

### Key NPM Packages
- `@tanstack/react-query`: Server state management
- `framer-motion`: Animation library
- `canvas-confetti`: Celebration effects
- `zod`: Schema validation
- `drizzle-zod`: Zod schema generation from Drizzle schemas
- `wouter`: Client-side routing

### Fonts (External CDN)
- Fredoka (display font)
- Nunito (body font)
- Google Fonts loaded via HTML