import { useState, useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { QUESTIONS } from "@/lib/questions";
import { Timer } from "@/components/Timer";
import { GameCard } from "@/components/GameCard";
import { FeedbackOverlay } from "@/components/FeedbackOverlay";
import { Trophy, ArrowLeft } from "lucide-react";

// Shuffle function for questions
function shuffle<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export default function Game() {
  const [_, setLocation] = useLocation();
  const [params] = useState(() => new URLSearchParams(window.location.search));
  const selectedLevel = params.get("level") || "mudah";
  
  // Randomize questions for every session
  const randomizedQuestions = useMemo(() => {
    const filtered = QUESTIONS.filter(q => q.level === selectedLevel);
    const pool = filtered.length > 0 ? filtered : QUESTIONS;
    
    // Create a truly randomized copy of the pool
    const shuffled = [...pool];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }, [selectedLevel]);
  
  const [qIndex, setQIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [status, setStatus] = useState<"playing" | "answered" | "feedback">("playing");
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const currentQuestion = randomizedQuestions[qIndex];
  const isLastQuestion = qIndex === randomizedQuestions.length - 1;

  // Track the actual number displayed to the user (1, 2, 3...)
  const questionNumber = qIndex + 1;

  // Sound effects placeholders (could be added with Audio API)
  
  const handleAnswer = (option: string) => {
    if (status !== "playing") return;
    
    setSelectedOption(option);
    setStatus("answered");

    const isCorrect = option === currentQuestion.answer;
    
    // Tiny delay before showing feedback to let the user see their click
    setTimeout(() => {
      if (isCorrect) {
        setScore(s => s + 10);
      }
      setStatus("feedback");
    }, 600);
  };

  const handleTimeUp = () => {
    if (status !== "playing") return;
    setStatus("feedback"); // Show feedback immediately as wrong
  };

  const nextQuestion = () => {
    if (isLastQuestion) {
      // Pass score via query param or simple navigation
      // For a real app, we might use a global store context, but params work for simple apps
      setLocation(`/results?score=${score}`);
    } else {
      setQIndex(prev => prev + 1);
      setStatus("playing");
      setSelectedOption(null);
    }
  };

  if (!currentQuestion) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col p-4 md:p-8 font-body">
      {/* Header */}
      <div className="flex justify-between items-center mb-8 max-w-5xl mx-auto w-full">
        <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-xl shadow-sm border border-gray-100">
           <span className="text-gray-400 text-sm font-bold uppercase tracking-wider">Soal</span>
           <span className="text-xl font-black text-gray-800">{questionNumber}<span className="text-gray-300 text-lg">/{randomizedQuestions.length}</span></span>
        </div>

        <div className="flex items-center gap-2 bg-yellow-50 px-6 py-2 rounded-xl shadow-sm border border-yellow-100">
           <Trophy className="w-5 h-5 text-yellow-500 fill-current" />
           <span className="text-xl font-black text-yellow-600">{score}</span>
        </div>
      </div>

      <div className="max-w-4xl mx-auto w-full flex-1 flex flex-col justify-center">
        {/* Timer */}
        <Timer 
          key={qIndex} // Reset timer on question change
          duration={30} 
          onTimeUp={handleTimeUp}
          isRunning={status === "playing"}
        />

        {/* Question Card */}
        <motion.div
          key={`q-${qIndex}`}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
          className="text-center mb-12"
        >
          <span className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-bold rounded-full mb-4 uppercase tracking-wider">
            {currentQuestion.topic}
          </span>
          <h2 className="text-3xl md:text-4xl font-black text-gray-800 leading-tight font-display">
            {questionNumber}. {currentQuestion.question}
          </h2>
        </motion.div>

        {/* Options Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          {currentQuestion.options.map((opt, idx) => {
            const isSelected = selectedOption === opt;
            const isCorrectAnswer = opt === currentQuestion.answer;
            
            // Logic for visual states during feedback
            let isCorrect = false;
            let isWrong = false;

            if (status === "feedback") {
              if (isCorrectAnswer) isCorrect = true;
              if (isSelected && !isCorrectAnswer) isWrong = true;
            }

            return (
              <GameCard
                key={idx}
                index={idx}
                option={opt}
                onClick={() => handleAnswer(opt)}
                disabled={status !== "playing"}
                isSelected={isSelected}
                isCorrect={isCorrect}
                isWrong={isWrong}
              />
            );
          })}
        </div>
      </div>

      {/* Feedback Overlay Modal */}
      <FeedbackOverlay 
        isVisible={status === "feedback"}
        isCorrect={selectedOption === currentQuestion.answer}
        explanation={currentQuestion.explanation}
        onNext={nextQuestion}
      />
    </div>
  );
}
